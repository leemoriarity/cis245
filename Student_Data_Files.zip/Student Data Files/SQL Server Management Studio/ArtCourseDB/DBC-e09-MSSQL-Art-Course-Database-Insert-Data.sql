/********************************************************************************/
/*																				*/
/*	Kroenke, Auer, Vandenberg, and Yoder 					*/
/*	Database Concepts (9th Edition) Chapters 01, 03 	       		*/
/*																				*/
/*	Art-Course-Database Insert Data												*/
/*																				*/
/*	These are the Microsoft SQL Server 2017 SQL code solutions				*/
/*																				*/
/********************************************************************************/

USE Art_Course_Database
GO

/*****   CUSTOMER DATA   ********************************************************/

INSERT INTO CUSTOMER VALUES(
	'Johnson', 'Ariel','206-567-1234');
INSERT INTO CUSTOMER VALUES(
	'Green', 'Robin', '425-678-8765');
INSERT INTO CUSTOMER VALUES(
	'Jackson', 'Charles','360-789-3456');
INSERT INTO CUSTOMER VALUES(
	'Pearson', 'Jeffery', '206-567-2345');
INSERT INTO CUSTOMER VALUES(
	'Sears', 'Miguel','360-789-4567');
INSERT INTO CUSTOMER VALUES(
	'Kyle', 'Leah', '425-678-7654');
INSERT INTO CUSTOMER VALUES(
	'Myers', 'Lynda', '360-789-5678');


/*****   COURSE DATA   **********************************************************/

INSERT INTO COURSE VALUES(
	'Adv Pastels', '01-OCT-19', 500.00);
INSERT INTO COURSE VALUES(
	'Beg Oils', '15-SEP-19', 350.00);
INSERT INTO COURSE VALUES(
	'Int Pastels', '15-MAR-19', 350.00);
INSERT INTO COURSE VALUES(
	'Beg Oils', '15-OCT-19', 350.00);
INSERT INTO COURSE VALUES(
	'Adv Pastels', '15-NOV-19', 500.00);


/*****   ENROLLMENT DATA   ******************************************************/

INSERT INTO ENROLLMENT VALUES(1, 1, 250.00);
INSERT INTO ENROLLMENT VALUES(1, 3, 350.00);
INSERT INTO ENROLLMENT VALUES(2, 2, 350.00);
INSERT INTO ENROLLMENT VALUES(3, 1, 500.00);
INSERT INTO ENROLLMENT VALUES(4, 1, 500.00);
INSERT INTO ENROLLMENT VALUES(5, 2, 350.00);
INSERT INTO ENROLLMENT VALUES(6, 5, 250.00);
INSERT INTO ENROLLMENT VALUES(7, 4, 0.00);


/****************************************************************************************/

