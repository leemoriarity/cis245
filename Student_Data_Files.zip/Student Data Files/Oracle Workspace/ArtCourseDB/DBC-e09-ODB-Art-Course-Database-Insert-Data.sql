/********************************************************************************/
/*																				                                      */
/*	Kroenke, Auer, Vandenberg, and Yoder 					*/
/*	Database Concepts (9th Edition)  	       		*/
/*						                                    */
/*	Art-Course-Database Insert Data										                      */
/*																				                                      */
/*	These are the Oracle Express 11GR2 SQL code solutions	                        				*/
/*																				                                      */
/********************************************************************************/

/*****   CUSTOMER DATA   ********************************************************/

INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Johnson', 'Ariel','206-567-1234');
INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Green', 'Robin', '425-678-8765');
INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Jackson', 'Charles','360-789-3456');
INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Pearson', 'Jeffery', '206-567-2345');
INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Sears', 'Miguel','360-789-4567');
INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Kyle', 'Leah', '425-678-7654');
INSERT INTO CUSTOMER VALUES
  (seqCustomerID.Nextval, 'Myers', 'Lynda', '360-789-5678');


/*****   COURSE DATA   **********************************************************/

INSERT INTO COURSE VALUES
  (seqCourseID.Nextval, 'Adv Pastels', TO_DATE('10/01/2019', 'MM/DD/YYYY'), 500.00);
INSERT INTO COURSE VALUES
  (seqCourseID.Nextval, 'Beg Oils', TO_DATE('09/15/2019', 'MM/DD/YYYY'), 350.00);
INSERT INTO COURSE VALUES
  (seqCourseID.Nextval, 'Int Pastels', TO_DATE('03/15/2019', 'MM/DD/YYYY'), 350.00);
INSERT INTO COURSE VALUES
  (seqCourseID.Nextval, 'Beg Oils', TO_DATE('10/15/2019', 'MM/DD/YYYY'), 350.00);
INSERT INTO COURSE VALUES
  (seqCourseID.Nextval, 'Adv Pastels', TO_DATE('11/15/2019', 'MM/DD/YYYY'), 500.00);


/*****   ENROLLMENT DATA   ******************************************************/

INSERT INTO ENROLLMENT VALUES(1, 1, 250.00);
INSERT INTO ENROLLMENT VALUES(1, 3, 350.00);
INSERT INTO ENROLLMENT VALUES(2, 2, 350.00);
INSERT INTO ENROLLMENT VALUES(3, 1, 500.00);
INSERT INTO ENROLLMENT VALUES(4, 1, 500.00);
INSERT INTO ENROLLMENT VALUES(5, 2, 350.00);
INSERT INTO ENROLLMENT VALUES(6, 5, 250.00);
INSERT INTO ENROLLMENT VALUES(7, 4, 0.00);

/********************************************************************************/